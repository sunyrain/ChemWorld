def _initial_prompt(cell: Mapping[str, Any]) -> str:
    packet = cell["public_packet"]
    public = {
        "task_id": cell["task_id"],
        "initial_world_model": cell["initial_world_model"],
        "metric_range": packet["metric_range"],
        "scoring_queries": packet["scoring_queries"],
    }
    return (
        "You are a scientific participant in a matched-evidence belief-updating study. "
        "Do not use shell, files, web, apps, plugins, MCP, or other tools. No experimental "
        "evidence is available in this first turn. Use only the supplied task and initial world "
        "model to predict every requested metric for every scoring query. Values must be in "
        "[0,1]. Return only the schema-conforming JSON; model_summary must be a concise public "
        "scientific summary, not private chain-of-thought.\n\nINPUT:\n"
        + json.dumps(public, ensure_ascii=False, sort_keys=True)
    )

def _evidence_prompt(cell: Mapping[str, Any]) -> str:
    packet = cell["public_packet"]
    public = {
        "task_id": cell["task_id"],
        "evidence": packet["evidence"],
        "scoring_queries": packet["scoring_queries"],
    }
    return (
        "The evaluator now reveals the fixed matched-evidence packet below. Treat these measured "
        "observations as authoritative. Without using any tool, update your model and predict all "
        "metrics for the same scoring queries. Do not merely repeat the evidence values because "
        "the scoring queries are disjoint. Return only schema-conforming JSON. model_summary and "
        "evidence_assessment must be concise public scientific summaries, not private "
        "chain-of-thought.\n\nMATCHED_EVIDENCE_INPUT:\n"
        + json.dumps(public, ensure_ascii=False, sort_keys=True)
    )

def _b3_initial_prompt(cell: Mapping[str, Any]) -> str:
    packet = cell["public_packet"]
    public = {
        "task_id": cell["task_id"],
        "initial_world_model": cell["initial_world_model"],
        "candidate_mechanism_families": packet["candidate_mechanism_families"],
        "metric_range": packet["metric_range"],
        "scoring_action_queries": packet["scoring_action_queries"],
    }
    return (
        "You are a scientific participant in a two-turn constitutive-law identification study. "
        "Do not use shell, files, web, apps, plugins, MCP, or any other tool. No measured evidence "
        "is available in this turn. Use only the supplied initial model, anonymous candidate "
        "families, public reference coefficients, and query controls. Commit independently to one "
        "mechanism family, one numerical reference-coefficient exponent, one typed executable law, "
        "and predictions for every metric of every unseen scoring/action query. Return only the "
        "schema-conforming JSON. model_summary must be a concise public scientific statement, not "
        "private chain-of-thought.\n\nINPUT:\n"
        + json.dumps(public, ensure_ascii=False, sort_keys=True)
    )

def _b3_evidence_prompt(cell: Mapping[str, Any]) -> str:
    packet = cell["public_packet"]
    public = {
        "task_id": cell["task_id"],
        "candidate_mechanism_families": packet["candidate_mechanism_families"],
        "evidence": packet["evidence"],
        "scoring_action_queries": packet["scoring_action_queries"],
    }
    action_selection_encoding = str(cell.get("action_selection_encoding", "query_id"))
    if action_selection_encoding == "query_id":
        selection_field = "selected_action_query_id"
        selection_instruction = (
            "select exactly one scoring/action query ID as the novel action you would execute "
            "and return it as selected_action_query_id"
        )
    else:
        selection_field = "selected_action_index"
        selection_instruction = (
            "select exactly one visible zero-based action_index (0 through 7) as the novel "
            "action you would execute and return it as selected_action_index"
        )
    return (
        "The evaluator now reveals the fixed evidence packet. Each evidence recipe reports both "
        "the public linear-reference calibration and the measured target-world observation under "
        "the same controls. The scoring/action queries are disjoint and have never been executed "
        "for you. Treat the evidence as authoritative. Update the mechanism family, exponent, "
        f"typed law, and all predictions, then {selection_instruction}. The first-turn JSON shape "
        "is not sufficient for this turn. In addition to the updated model fields, the post JSON "
        f"must include both {selection_field} and evidence_assessment. Do not invent a free-text "
        "recipe. Return only "
        "schema-conforming "
        "JSON; summaries must be public scientific statements, not private chain-of-thought.\n\n"
        "EVIDENCE_INPUT:\n"
        + json.dumps(public, ensure_ascii=False, sort_keys=True)
    )
