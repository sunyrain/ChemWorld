#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
for row in manifest["files"]:
    path = ROOT / row["path"]
    assert path.is_file(), row["path"]
    assert path.stat().st_size == row["bytes"], row["path"]
    assert sha256(path) == row["sha256"], row["path"]

report = json.loads((ROOT / "data/publication_report.json").read_text(encoding="utf-8"))
models = report["action_extension"]["models"]
deepseek = models["deepseek"]["primary_all_scheduled"]["contrasts"]
gpt = models["gpt_5_6_sol"]["primary_all_scheduled"]["contrasts"]


def jsonl(path):
    return [
        json.loads(line)
        for line in (ROOT / path).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def close(left, right):
    assert math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1e-12), (
        left,
        right,
    )


def contrast(rows, name):
    return next(row for row in rows if row["contrast"] == name)


action_rows = jsonl("data/four_condition_scheduled_rows.jsonl")
assert len(action_rows) == 360
contrast_conditions = {
    "autonomous_exploration_minus_no_evidence": (
        "autonomous_exploration",
        "no_evidence",
    ),
    "yoked_evidence_minus_no_evidence": ("yoked_evidence", "no_evidence"),
    "learned_law_only_minus_no_evidence": ("learned_law_only", "no_evidence"),
    "autonomous_exploration_minus_yoked_evidence": (
        "autonomous_exploration",
        "yoked_evidence",
    ),
}
effect = "mean_failure_aware_normalized_regret_difference"
for model_name, published in (("deepseek", deepseek), ("gpt_5_6_sol", gpt)):
    model_rows = [row for row in action_rows if row["participant"] == model_name]
    assert len(model_rows) == 180
    by_condition = {}
    for row in model_rows:
        by_condition.setdefault(row["condition"], {})[row["stratum_id"]] = row
    assert set(by_condition) == {
        "autonomous_exploration",
        "no_evidence",
        "yoked_evidence",
        "learned_law_only",
    }
    assert all(len(rows) == 45 for rows in by_condition.values())
    for name, (left_name, right_name) in contrast_conditions.items():
        left = by_condition[left_name]
        right = by_condition[right_name]
        assert set(left) == set(right)
        replayed = mean(
            float(left[stratum]["failure_aware_normalized_regret"])
            - float(right[stratum]["failure_aware_normalized_regret"])
            for stratum in sorted(left)
        )
        close(replayed, contrast(published, name)[effect])

decision = report["longitudinal_open_action"]["decision_aligned_law_action"]["overall"]
assert decision["law_evaluated_count"] == 45
assert decision["law_implied_top1_count"] == 0
assert decision["participant_top1_count"] == 11
assert decision["law_implied_top1_followed_count"] == 12
assert decision["law_action_agreement_evaluable_count"] == 42

c2_rows = jsonl("data/c2_cell_records.jsonl")
assert len(c2_rows) == 270
c2 = report["c2_denominators"]["models"]
fields = (
    "completed_cell_count",
    "checkpoint_scored_count",
    "law_evaluated_count",
    "blind_gain_evaluable_count",
)
for model_name in ("deepseek", "gpt_5_6_sol"):
    rows = [row for row in c2_rows if row["model"] == model_name]
    assert len(rows) == 135
    replayed = {
        "completed_cell_count": sum(bool(row["qualification_passed"]) for row in rows),
        "checkpoint_scored_count": sum(
            int(row["checkpoint_error"]["scored_snapshot_count"]) for row in rows
        ),
        "law_evaluated_count": sum(
            row["law_summary"].get("status") == "evaluated" for row in rows
        ),
        "blind_gain_evaluable_count": sum(
            row["blind"].get("recommendation_gain_over_incumbent") is not None
            for row in rows
        ),
    }
    assert tuple(replayed[field] for field in fields) == tuple(
        c2[model_name][field] for field in fields
    )

b3_rows = jsonl("data/b3_cell_records.jsonl")
assert len(b3_rows) == 60
b3 = report["b3_denominators"]["models"]
eligibility_by_coordinate = {}
for row in b3_rows:
    coordinate = (row["cluster_id"], row["arm"], row["replicate_index"])
    eligibility = row["action_opportunity_eligible"]
    if eligibility is not None:
        prior = eligibility_by_coordinate.setdefault(coordinate, bool(eligibility))
        assert prior == bool(eligibility)
assert sum(eligibility_by_coordinate.values()) == 18
for model_name in ("deepseek", "gpt_5_6_sol"):
    rows = [row for row in b3_rows if row["participant"] == model_name]
    assert len(rows) == 30
    completed = [row for row in rows if row["completed"]]
    eligible = [row for row in completed if row["action_opportunity_eligible"]]
    published = b3[model_name]
    failures = Counter(
        str(row["failure_classification"])
        for row in rows
        if not row["completed"]
    )
    assert published["completed_cell_count"] == len(completed)
    assert published["failed_cell_count"] == len(rows) - len(completed)
    assert published["failure_classification_counts"] == dict(sorted(failures.items()))
    assert published["joint_law_recovery_count"] == sum(
        bool(row["joint_family_exponent_recovery"]) for row in rows
    )
    assert published["top1_count"] == sum(bool(row["top1_selected"]) for row in rows)
    close(
        published["mean_failure_aware_regret"],
        mean(float(row["normalized_regret"]) for row in rows),
    )
    close(
        published["completed_mean_post_mae"],
        mean(float(row["post_error"]) for row in completed),
    )
    assert published["useful_gain_completed_opportunity"] == {
        "count": sum(float(row["selected_action_gain"]) >= 0.02 for row in eligible),
        "denominator": len(eligible),
    }
    assert published["useful_gain_scheduled_opportunity"]["denominator"] == 18

assert b3["deepseek"]["useful_gain_completed_opportunity"] == {"count": 0, "denominator": 13}
assert b3["gpt_5_6_sol"]["useful_gain_completed_opportunity"] == {"count": 0, "denominator": 18}
assert b3["deepseek"]["useful_gain_scheduled_opportunity"]["denominator"] == 18
assert b3["gpt_5_6_sol"]["useful_gain_scheduled_opportunity"]["denominator"] == 18

b2 = report["b2_expression_and_identifiability"]
assert len(b2["public_summary_rows"]) == 45
identifiability = b2["participant_visible_identifiability"]
assert identifiability["decision"]["structural_family_identification_supported"] is False
assert identifiability["exact_alias"]["present"] is True
assert identifiability["positive_control"]["readout_positive_control_passed"] is False
assert round(identifiability["constant_endpoint_baseline"]["mean_scoring_error"], 5) == 0.00649
expected_exact = {
    "deepseek_v4_flash_high": (1, 0),
    "gpt_5_6_sol_medium": (0, 0),
    "deepseek_v4_flash_low": (2, 0),
}
for configuration, (aligned, misspecified) in expected_exact.items():
    audit = b2["configuration_summaries"][configuration]["public_expression_audit_by_arm"]
    assert audit["aligned_nominal"]["exact_1_75_power_law_recovery_count"] == aligned
    assert audit["misindexed_nominal"]["exact_1_75_power_law_recovery_count"] == misspecified

coding_path = ROOT / "methods/b2_expression_coding.py"
spec = importlib.util.spec_from_file_location("b2_expression_coding", coding_path)
assert spec is not None and spec.loader is not None
coding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(coding)
rows = [
    json.loads(line)
    for line in (ROOT / "data/b2_public_summary_rows.jsonl")
    .read_text(encoding="utf-8")
    .splitlines()
    if line.strip()
]
assert len(rows) == 45
for configuration in expected_exact:
    observed = coding.audit_flat_public_rows(
        [row for row in rows if row["configuration"] == configuration]
    )
    expected = b2["configuration_summaries"][configuration][
        "public_expression_audit_by_arm"
    ]
    assert observed["by_arm"] == expected

boundaries = report["claim_boundaries"]
assert boundaries["matched_evidence_conditional_post_packet_response_supported"] is True
assert boundaries["matched_evidence_pure_packet_effect_supported"] is False
assert boundaries["b2_structural_family_identification_supported"] is False

print(f"verified {len(manifest['files'])} files and all publication invariants")
