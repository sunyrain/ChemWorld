from __future__ import annotations
import json
from statistics import mean
from methods.final_diagnostic_interface import (
    prompt as minimal_prompt, validate, METRICS)
def prompt(cell: dict, stage: str, tool: str) -> str:
    instruction, serialized = minimal_prompt(cell, stage, tool).rsplit("\n", 1)
    public = json.loads(serialized)
    public["candidate_parameter_domains"] = cell["public_packet"]["candidate_parameter_domains"]
    if stage == "post" and cell["information"] == "complete":
        public["complete_observation_contract"] = cell["public_packet"][
            "complete_observation_contract"
        ]
    return instruction + "\n" + json.dumps(public, sort_keys=True)

def score(result: dict, cell: dict) -> dict:
    row = {k: cell[k] for k in ("cell_id", "cluster_id", "arm", "model", "information")}
    row.update(
        status=result["status"],
        failure=result.get("failure"),
        joint_recovery=0,
        normalized_regret=1.0,
        top1=0,
        tool_used=bool(result.get("tool_audit")),
    )
    truth = cell["scoring_truth"]
    for stage in ("pre", "post"):
        payload = result.get(stage)
        if payload is None:
            continue
        try:
            validate(payload, cell, stage)
        except ValueError:
            continue
        row[stage + "_exponent_abs_error"] = abs(payload["exponent"] - cell["target_exponent"])
        row[stage + "_family"] = payload["family"]
        row[stage + "_exponent"] = payload["exponent"]
        row[stage + "_mae"] = mean(
            abs(payload["predictions"][q][m] - truth[q][m]) for q in truth for m in METRICS
        )
    if result["status"] == "completed":
        payload = result["post"]
        validate(payload, cell, "post")
        row["joint_recovery"] = int(
            payload["family"] == "FAMILY_B_POWER"
            and abs(payload["exponent"] - cell["target_exponent"]) <= 0.1
        )
        scores = [t["score"] for t in truth.values()]
        raw = max(scores) - truth[payload["selected_query_id"]]["score"]
        row.update(
            raw_regret=raw,
            normalized_regret=raw / max(max(scores) - min(scores), 1e-12),
            top1=int(raw <= 1e-8),
            near_optimal=int(raw <= 0.01),
        )
    return row
