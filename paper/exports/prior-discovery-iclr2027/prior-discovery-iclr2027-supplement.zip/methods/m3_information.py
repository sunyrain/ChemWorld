from __future__ import annotations
import json
import math
from copy import deepcopy
from collections.abc import Sequence
from typing import Any
BASIS = ['1', 'x', 'y', 'x*x', 'x*y', 'y*y']
CONDITIONS = ('none', 'raw', 'L', 'F')

def validate_payload(payload: Any, stage: str, candidate_ids: Sequence[str] = ()) -> None:
    key = "coefficients" if stage == "source" else "candidate_id"
    if not isinstance(payload, dict) or set(payload) != {key}:
        raise ValueError(f"expected only {key}")
    if stage == "source":
        values = payload[key]
        if (
            not isinstance(values, list)
            or len(values) != 6
            or any(
                isinstance(value, bool)
                or not isinstance(value, int | float)
                or not math.isfinite(value)
                for value in values
            )
        ):
            raise ValueError("coefficients must be six finite numbers")
    elif payload[key] not in candidate_ids:
        raise ValueError("unknown candidate ID")

def recipient_input(packet: dict, condition: str, coefficients: list | None) -> dict:
    if condition not in CONDITIONS:
        raise ValueError("unknown information condition")
    public = {key: deepcopy(packet[key]) for key in ("task_id", "axes", "basis", "utility")}
    public["candidates"] = [
        {key: deepcopy(row[key]) for key in ("id", "xy", "controls", "action_plan")}
        for row in packet["candidates"]
    ]
    if condition == "raw":
        public["evidence"] = [
            {key: deepcopy(row[key]) for key in ("id", "xy", "controls", "action_plan", "score")}
            for row in packet["evidence"]
        ]
    if condition in ("L", "F"):
        validate_payload({"coefficients": coefficients}, "source")
        public["artifact"] = {"coefficients": list(coefficients), "basis": BASIS}
    return public

def recipient_prompt(packet: dict, condition: str, coefficients: list | None) -> str:
    return (
        "You are a scientific participant. Use only INPUT; no tools, shell, files, web, "
        "apps or external data. Give only the minimal JSON, within 2048 output tokens. "
        "x and y are the supplied normalized coordinates. If a quadratic artifact is supplied, "
        "u=b0+b1*x+b2*y+b3*x*x+b4*x*y+b5*y*y; it is an unclipped approximation, "
        "not a guaranteed true law. Choose one candidate to maximize utility using the "
        'information provided. Return only {"candidate_id":"..."}. '
        "\nINPUT:\n"
        + json.dumps(
            recipient_input(packet, condition, coefficients),
            ensure_ascii=False,
            separators=(",", ":"),
        )
    )
