from __future__ import annotations
import json
import math
from typing import Any
METRICS = ('product_in_organic', 'product_in_aqueous', 'phase_ratio', 'score')
FAMILIES = ('FAMILY_A_LINEAR', 'FAMILY_B_POWER', 'FAMILY_C_SATURATING', 'FAMILY_D_CONSTANT')

def schema(cell: dict, stage: str) -> dict:
    number = {"type": "number", "minimum": 0, "maximum": 1}
    predictions = {}
    for query in cell["public_packet"]["scoring_action_queries"]:
        predictions[query["query_id"]] = {
            "type": "object",
            "properties": dict.fromkeys(METRICS, number),
            "required": list(METRICS),
            "additionalProperties": False,
        }
    properties = {
        "family": {"type": "string", "enum": list(FAMILIES)},
        "exponent": {"type": "number", "minimum": 0.25, "maximum": 3},
        "predictions": {
            "type": "object",
            "properties": predictions,
            "required": list(predictions),
            "additionalProperties": False,
        },
    }
    if stage == "post":
        properties["selected_query_id"] = {"type": "string", "enum": list(predictions)}
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }

def validate(payload: Any, cell: dict, stage: str) -> dict:
    contract = schema(cell, stage)
    if not isinstance(payload, dict) or set(payload) != set(contract["required"]):
        raise ValueError("minimal submission fields mismatch")
    if payload["family"] not in FAMILIES:
        raise ValueError("invalid family")
    exponent = payload["exponent"]
    if (
        type(exponent) not in (int, float)
        or not math.isfinite(exponent)
        or not 0.25 <= exponent <= 3
    ):
        raise ValueError("invalid exponent")
    predictions = payload["predictions"]
    ids = contract["properties"]["predictions"]["required"]
    if not isinstance(predictions, dict) or set(predictions) != set(ids):
        raise ValueError("prediction query coverage mismatch")
    for values in predictions.values():
        if not isinstance(values, dict) or set(values) != set(METRICS):
            raise ValueError("prediction metric coverage mismatch")
        if any(
            type(v) not in (int, float) or not math.isfinite(v) or not 0 <= v <= 1
            for v in values.values()
        ):
            raise ValueError("prediction must be finite and in [0,1]")
    if stage == "post" and payload["selected_query_id"] not in ids:
        raise ValueError("invalid candidate")
    return {
        "law_type": "reference_coefficient_power",
        "mechanism_family": payload["family"],
        "reference_exponent": exponent,
    }

def prompt(cell: dict, stage: str, tool: str) -> str:
    packet = cell["public_packet"]
    public = {
        key: packet[key]
        for key in (
            "task_id",
            "metric_range",
            "candidate_mechanism_families",
            "scoring_action_queries",
        )
    }
    if stage == "pre":
        public["initial_world_model"] = cell["initial_world_model"]
        instruction = "No target measurements are available yet. No tools are available."
    else:
        public["evidence"] = packet["evidence"]
        instruction = (
            "Here is the fixed evidence: public linear-reference calibration "
            "and target observations "
            "under matched controls. Update your answer and select one unseen scoring query ID. "
            + (
                "You may use public_numerics.calculate for up to 8 numerical calculations. "
                "It accepts literal expressions: +,-,*,/,**, "
                "array,log,exp,sqrt,abs,mean,sum,min,max,"
                "clip,linspace(start,stop,count),lstsq(design_matrix,target_vector). "
                "It has no simulator or hidden information. Tool use is optional."
                if tool == "on"
                else "No tools are available."
            )
        )
    return (
        "You are a scientific participant in a two-turn constitutive-law study. "
        + instruction
        + " Use only the supplied public information. "
        "No shell, files, web, other tools, or agents. "
        "Return only JSON with family, exponent, predictions keyed by query ID"
        + (", and selected_query_id" if stage == "post" else "")
        + ". Declare family/exponent once; the host maps these fields directly to the original "
        "typed-law commitment without fitting or correcting them. Predictions contain all four "
        "metric values in [0,1] for each query. "
        "Do not include status, explanations or extra fields.\n"
        + json.dumps(public, sort_keys=True)
    )
