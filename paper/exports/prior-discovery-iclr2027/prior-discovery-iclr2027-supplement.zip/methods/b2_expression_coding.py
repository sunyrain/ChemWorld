from collections.abc import Mapping, Sequence
from typing import Any

ARMS = ("opaque", "aligned_nominal", "misindexed_nominal")

def _public_text(cell: Mapping[str, Any]) -> str:
    return (
        str(cell["post_prediction"]["model_summary"])
        + " "
        + str(cell["post_prediction"]["evidence_assessment"])
    ).lower()

def _public_summary_audit(cells: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    rows: dict[str, list[dict[str, Any]]] = {arm: [] for arm in ARMS}
    exact_power_markers = (
        "exponent 1.75",
        "1.75-power",
        "1.75 power",
        "partition exponent 1.75",
    )
    power_compatible_markers = (
        "confirms the power-response",
        "corroborate the power-response",
        "power-response model's qualitative prediction",
        "nonlinear (superlinear) partition response",
    )
    saturation_markers = (
        "saturat",
        "nearly independent",
        "near-constant",
        "nearly constant",
        "fixed reference recovery",
        "fixed recovery ceiling",
        "flat at",
        "tightly clustered",
    )
    for cell in sorted(cells, key=lambda item: (item["arm"], item["world_seed"])):
        arm = str(cell["arm"])
        text = _public_text(cell)
        exact_power = any(marker in text for marker in exact_power_markers)
        power_compatible = exact_power or any(
            marker in text for marker in power_compatible_markers
        )
        explicit_linear_rejection = (
            "d*r/(1+d*r)" in text and "reject" in text
        ) or (
            ("linear reference" in text or "initial linear" in text)
            and any(marker in text for marker in ("reject", "contradict", "not support"))
        )
        explicit_supplied_power_rejection = (
            arm == "aligned_nominal"
            and "contradict" in text
            and ("power-law" in text or "power response" in text)
        )
        rows[arm].append(
            {
                "world_seed": int(cell["world_seed"]),
                "exact_1_75_power_law_recovery": exact_power,
                "power_compatible_language": power_compatible,
                "explicit_supplied_linear_partition_rejection": explicit_linear_rejection,
                "explicit_supplied_power_rejection": explicit_supplied_power_rejection,
                "empirical_saturation_or_endpoint_model": any(
                    marker in text for marker in saturation_markers
                ),
            }
        )
    return {
        "source": "participant_public_model_summary_and_evidence_assessment_only",
        "private_reasoning_used": False,
        "by_arm": {
            arm: {
                "world_count": len(arm_rows),
                "exact_1_75_power_law_recovery_count": sum(
                    row["exact_1_75_power_law_recovery"] for row in arm_rows
                ),
                "power_compatible_language_count": sum(
                    row["power_compatible_language"] for row in arm_rows
                ),
                "explicit_supplied_linear_partition_rejection_count": sum(
                    row["explicit_supplied_linear_partition_rejection"] for row in arm_rows
                ),
                "explicit_supplied_power_rejection_count": sum(
                    row["explicit_supplied_power_rejection"] for row in arm_rows
                ),
                "empirical_saturation_or_endpoint_model_count": sum(
                    row["empirical_saturation_or_endpoint_model"] for row in arm_rows
                ),
                "world_rows": arm_rows,
            }
            for arm, arm_rows in rows.items()
        },
    }


def audit_flat_public_rows(
    rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    normalized = [
        {
            "arm": row["arm"],
            "world_seed": row["world_index"],
            "post_prediction": {
                "model_summary": row["model_summary"],
                "evidence_assessment": row["evidence_assessment"],
            },
        }
        for row in rows
    ]
    audit = _public_summary_audit(normalized)
    audit["by_arm"] = {
        arm: {
            key: value
            for key, value in arm_audit.items()
            if key != "world_rows"
        }
        for arm, arm_audit in audit["by_arm"].items()
    }
    return audit
