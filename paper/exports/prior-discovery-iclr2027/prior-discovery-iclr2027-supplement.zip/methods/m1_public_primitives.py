from __future__ import annotations
import json
import math
from copy import deepcopy
from collections.abc import Mapping, Sequence
from typing import Any
import numpy as np

BASIS = ['1', 'x', 'y', 'x*x', 'x*y', 'y*y']

def normalized_design(count: int, seed: int) -> list[list[float]]:
    """Outcome-blind LHS rejection preserves strata and the two-task pairing."""
    rng = np.random.default_rng(seed)
    for _ in range(10000):
        points = np.column_stack(
            [(rng.permutation(count) + rng.random(count)) / count for _ in range(2)]
        )
        potential = 0.65 + points[:, 0]
        current = 20 + 100 * points[:, 1]
        if np.all(np.abs(potential - 1.18) >= 0.02) and np.all(np.abs(current - 70) >= 1):
            return points.tolist()
    raise ValueError("no valid design within the fixed outcome-blind search limit")

def public_packet(packet: Mapping[str, Any], *, candidates: bool) -> dict[str, Any]:
    """Explicit projection: trajectories, world identity and hidden scores cannot enter."""
    result = {key: deepcopy(packet[key]) for key in ("task_id", "axes", "basis", "utility")}
    result["evidence"] = [
        {key: deepcopy(row[key]) for key in ("id", "xy", "controls", "action_plan", "score")}
        for row in packet["evidence"]
    ]
    if candidates:
        result["candidates"] = [
            {key: deepcopy(row[key]) for key in ("id", "xy", "controls", "action_plan")}
            for row in packet["candidates"]
        ]
    return result

def design_matrix(rows: Sequence[Mapping[str, Any]]) -> np.ndarray:
    xy = np.asarray([row["xy"] for row in rows], dtype=float)
    x, y = xy[:, 0], xy[:, 1]
    return np.column_stack([np.ones(len(rows)), x, y, x * x, x * y, y * y])

def fit_public_law(evidence: Sequence[Mapping[str, Any]], ridge: float = 1e-6) -> list[float]:
    matrix = design_matrix(evidence)
    scores = np.asarray([row["score"] for row in evidence], dtype=float)
    penalty = np.diag([0.0, ridge, ridge, ridge, ridge, ridge])
    return np.linalg.solve(matrix.T @ matrix + penalty, matrix.T @ scores).tolist()

def output_schema(stage: str, candidate_ids: Sequence[str] = ()) -> dict[str, Any]:
    key = "coefficients" if stage == "source" else "candidate_id"
    value: dict[str, Any] = (
        {"type": "array", "items": {"type": "number"}, "minItems": 6, "maxItems": 6}
        if stage == "source"
        else {"type": "string", "enum": list(candidate_ids)}
    )
    return {
        "type": "object",
        "properties": {key: value},
        "required": [key],
        "additionalProperties": False,
    }

def validate_payload(payload: Any, stage: str, candidate_ids: Sequence[str] = ()) -> None:
    key = "coefficients" if stage == "source" else "candidate_id"
    if not isinstance(payload, dict) or set(payload) != {key}:
        raise ValueError(f"expected only {key}")
    if stage == "source":
        values = payload[key]
        if (
            not isinstance(values, list)
            or len(values) != 6
            or any(
                isinstance(value, bool)
                or not isinstance(value, int | float)
                or not math.isfinite(value)
                for value in values
            )
        ):
            raise ValueError("coefficients must be six finite numbers")
    elif payload[key] not in candidate_ids:
        raise ValueError("unknown candidate ID")

def maximize(coefficients: Sequence[float], candidates: Sequence[Mapping[str, Any]]) -> str:
    predictions = design_matrix(candidates) @ np.asarray(coefficients)
    if not np.all(np.isfinite(predictions)):
        raise ValueError("non-finite artifact predictions")
    # Original candidate-ID order breaks exact ties; no clipping of the fitted surface.
    return str(candidates[int(np.argmax(predictions))]["id"])

def participant_prompt(packet: Mapping[str, Any], *, coefficients: Sequence[float] | None) -> str:
    source = coefficients is None
    public = public_packet(packet, candidates=not source)
    if not source:
        public["artifact"] = {"coefficients": list(coefficients), "basis": BASIS}
    task = (
        "Fit a useful local response surface from the public experiments. Return only "
        '{"coefficients":[b0,b1,b2,b3,b4,b5]}. '
        if source
        else "Choose one candidate to maximize utility, using the supplied public evidence and "
        'artifact. Return only {"candidate_id":"..."}. '
    )
    return (
        "You are a scientific participant. Use only INPUT; no tools, shell, files, web, "
        "apps or external data. Give only the minimal JSON, within 2048 output tokens. "
        "x and y are the supplied normalized coordinates; "
        "u=b0+b1*x+b2*y+b3*x*x+b4*x*y+b5*y*y. "
        "The artifact is an unclipped quadratic approximation, not a guaranteed true law. "
        + task
        + "\nINPUT:\n"
        + json.dumps(public, ensure_ascii=False, separators=(",", ":"))
    )

def nearest_public_choice(packet: Mapping[str, Any]) -> str:
    xy = np.asarray([row["xy"] for row in packet["evidence"]])
    scores = [row["score"] for row in packet["evidence"]]
    predicted = [
        scores[int(np.argmin(np.sum((xy - row["xy"]) ** 2, axis=1)))]
        for row in packet["candidates"]
    ]
    return str(packet["candidates"][int(np.argmax(predicted))]["id"])

def score_slots(slots: Sequence[Mapping[str, Any]], truth: Mapping[str, float]) -> list[dict]:
    best = max(truth.values())
    result = []
    for slot in slots:
        row = dict(slot)
        completed = row["status"] == "completed" and row.get("candidate_id") in truth
        regret = best - truth[row["candidate_id"]] if completed else None
        row.update(
            {
                "raw_regret": regret,
                "failure_aware_regret": regret if completed else 1.0,
                "near_optimal": completed and regret <= 0.01,
                "top1": completed and regret <= 1e-12,
            }
        )
        result.append(row)
    return result
