# 局部温度系列与资料分配模型共同支持高回收流程，改进原因仍有联合操作混杂

`repeat-02/P-W02-B12-optimization-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-02__P-W02-B12-optimization-E-Aligned.json)

## 问题与先验

正确资料指向X2，全程只用X2。首批HPLC后补组分并再热，剂量和催化剂量也不同，后续正确排除其与C1–C3的公平比较。C3/S0局部纯度与回收较好，转入C3四溶剂筛选。

## 预期与实验

v2/cursor119从S1洗与S2不洗的混杂比较提出洗涤损失，明确预期不洗C3/S1仍合格且提高回收，随后温度330/370/390/410K固定1800s。最后两批增加X2比例，并取消dry/concentrate，不只有相量改变。

## 实际证据

C3/S1同0.018mol双料、0.005mol催化剂，上游回收330/350/370/390/410K为0.096/0.130/0.171/0.205/0.253；该反应系列有匹配基础。终态低比例330K不洗回收0.008低于350K洗的0.020，不能单独证明省洗提升。410K高X2比例且省后处理最终0.811/0.143；420K同时加料和相量变动最终0.798/0.172。

## 修订

v3选纯度达标的第11批，保留第12批不合格。K1用资料系数预测源批6/11/12纯度与回收量级，形成可用局部解释，同时承认独立洗涤、dry/concentrate效果和真实分配动力学未识别。该定量解释发表于K1，不能倒写为事前预测命中。

## 后续采用

Q直接采用资料Ktarget2.585/Kimpurity0.552并把同式用于洗涤，预测X0更纯但低回收、等总量分洗更纯；这些比较从未实验。低料量回收0.263–0.370来自催化剂比例推断，也未定量识别。K2建议共同反应分样匹配相量、双相测量且无后处理，正是源研究未能隔离的因果项，未执行。

## 未解决问题及解释限制

资料可助解释和有效操作，但不能把全流程回收增长单归相量。无精确重复；420K的0.798与410K0.811不是同条件重复，不能据此估计跨门槛重复性。认识贡献包括局部温度关系、测量域区分以及有范围的资料模型应用。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 119, 'last_event_id': 'runner-operation-0119'}

> Testable consequence: unwashed S1/C3 should retain purity >=0.80 and improve recovery

K1

> the independent effects of drying and concentration are unidentifiable

K1

> X2 cannot be claimed globally optimal

Q

> applied the same relation again to aqueous washing.
