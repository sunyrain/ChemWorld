# 事前加剧反应检验形成局部权衡，重复实验暴露合格推荐的阈值脆弱性

`repeat-01/P-W04-B12-optimization-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2，读取已有推荐复测；非独立双人编码。

[完整公开记录](../sessions/repeat-01__P-W04-B12-optimization-E-Aligned.json)

## 问题与先验

Aligned资料支持X2分配及选择性优势。v1以完整反应和萃取争取纯度0.80；最初极小有机相加干燥浓缩导致终检样品不足，事件15/16拒绝后补有机相才完成该批，模型最后正确归为流程容量分配失败。

## 预期与实验

v2/cursor71根据340K/900s对角类别筛选聚焦S1/C1，预告提高反应强度：产率提高且不损选择性支持动力学受限，副产物增加则考虑低温长时。后续390K/3600s、370K/7200s及390K/1800s实际检验了温时组合，并扩展X0/X1。

## 实际证据

S1/C1从340K/900s产率0.034到390K/1800s约0.139—0.183，再至390K/3600s0.269，显示真实上游生成进展。强反应X2终态纯度0.706，低温长时加洗涤0.447；后者不能独立归因洗涤。batch10/12同完整X0配方重复，纯度0.80087/0.79685、回收0.03028/0.02878；X1batch11为0.80364/0.02410。

## 修订

v3限制X2普遍最优的预期，承认初始资料不足以确定全流程排名；重复使其明确不主张X0稳健优于X1。仍按既定观察门槛选择batch10最高合格回收，未因更高回收的不合格批改写成功。既有推荐复测纯度0.7935/回收0.03045，保持执行有效但目标不合格。

## 后续采用

Q依据新解释预测低催化剂满投料低回收、小投料同催化剂比例较高回收；Q07—12回收0.145—0.225并非源实验直接标定。K2承认催化剂浓度还是比例控制动力学未解决，提出同批时间序列分开并行杂质生成与后续降解；未执行该建议。

## 未解决问题及解释限制

同条件重复已提供推荐边界证据，资料和局部成功没有阻止公开修订。反应强度—最终纯度比较同时涉及萃取剂或洗涤时不能视为纯粹因果估计；对角筛选不能证明材料交互。v2称回收reaction-limited仍属解释，分离损失亦显著；后续分层报告对此有所补充。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 71, 'last_event_id': 'runner-operation-0071'}

> The next test increases severity for S1/C1; a substantial yield gain without loss of selectivity would support kinetic limitation

事件：runner-operation-0076, runner-operation-0084

v3 / cursor {'event_count': 163, 'last_event_id': 'runner-operation-0163'}

> No robust superiority of X0 over X1 is claimed.

事件：runner-operation-0137, runner-operation-0150, runner-operation-0163

K2

> Whether fractional conversion depends mainly on catalyst concentration or catalyst-to-reagent ratio is unresolved.
