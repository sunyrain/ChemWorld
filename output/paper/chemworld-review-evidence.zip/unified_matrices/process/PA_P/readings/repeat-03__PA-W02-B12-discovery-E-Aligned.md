# 记录修正库存与回收的概念，局部三档关系支撑预测但不确定未测交互

`repeat-03/PA-W02-B12-discovery-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-03__PA-W02-B12-discovery-E-Aligned.json)

## 问题与先验

资料倾向S2和X2/X3；初始笔记错把两相目标份额之和预期为recovery附近。只有初始与终末两版，不能恢复中间公开判断时序。

## 预期与实验

固定S2X2做三档相量和弱/标准/强混合，标准重复保留相反水相；材料筛选多为对角配对加S2X3/S1X2。

## 实际证据

相率/有机份额0.103/0.298、0.394/0.639、0.619/0.790，混合弱0.524、标准0.639/0.655、强0.727。溶剂体积固定但总液量并非完全相同，体积与组成效应仍相关。

## 修订

末笔记纠正相份额之和近初始库存1而非recovery，并明确最强混合也未建立平台。保留相的终检支持操作解释，不能当独立重复原两相状态。

## 后续采用

Q携带混合和相量趋势，未测S0X3/S2X0仍据资料预测，D2选Q06；K2指出分离时长转速效应、可分离关系及资料外推均未建立，建议Q05量下固定700rpm时间递增对照，未执行。

## 未解决问题及解释限制

末笔记首句称equilibrated protocol与自己后文平台未知不一致；局部稳健响应不证明平衡常数。正向贡献是概念校正、重复及范围限定，迁移边界主要在其他材料和独立时速维度。

## 已核验引文与事件锚点

v1 / cursor {'event_count': 0, 'last_event_id': None}

> product_in_organic + product_in_aqueous near recovery

v2 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> Final-assay recovery is not interchangeable with the sum of the two inventory fractions.

K2

> the categorical Q06 decision is more confident than the direct pair evidence warrants.
