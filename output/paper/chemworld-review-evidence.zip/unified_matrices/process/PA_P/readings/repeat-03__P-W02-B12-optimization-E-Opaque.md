# 未执行的洗涤被当作弱净化证据并进入预测，同时真实材料筛选仍成立

`repeat-03/P-W02-B12-optimization-E-Opaque`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-03__P-W02-B12-optimization-E-Opaque.json)

## 问题与先验

无资料；首批add_phase organic建立相体系，其余十一批改用add_extractant却未先建相体系，萃取、混合、分相、洗涤等均连续has_phase_system拒绝。所有12批仍有真实反应与终检，故完整研究状态不意味着净化实施成功。

## 预期与实验

v2/cursor105把HPLC与终检相近解释为workup作用小，计划C1S1强洗与换X。实际批8两次0.04L洗及批9水相保留均拒绝，未构成洗涤或保留相对照。

## 实际证据

批8事件0112—0118均拒绝、终检0.571/0.257；批9事件0127—0130拒绝、终检0.558/0.278。研究者把近似不变解释为净化无效，而真实原因是这些动作未执行。另一方面S1下C0/C1/C2/C3终检回收0.187/0.273/0.127/0.294及上游差异确实支持类别效应。

## 修订

v3和K1撤回强洗能达到0.80的预期，但依据的是未实施操作，属于对研究经历的错误重建；K1进一步猜目标与杂质分配相近、反应选择性才是瓶颈。K2修正交互不可与主效应分离，却仍没有纠正净化未执行的事实。

## 后续采用

Q明确说洗涤小幅增纯减回收consistent with batches 2 and 8，封存预测因此采用来自不存在洗涤对照的经验支持。Q07/Q08纯度0.62→0.65、回收0.39→0.36，Q09/Q10分段洗方向同样。K2建议复制batch6流程换C3，仍引用未实现的X2工作流。

## 未解决问题及解释限制

不能把所有结果判为无效：反应类别比较有实测依据，最佳C3S1仍是非达标真实候选。核心错误发生于行动成功状态与化学证据之间，而非测量数字造假或provider失败。是否真因由该错误造成Q偏差还需另有对照，不由本场推出。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 105, 'last_event_id': 'runner-operation-0105'}

> suggesting workup so far has modest effects.

v3 / cursor {'event_count': 171, 'last_event_id': 'runner-operation-0171'}

> Neither stronger repeated washing nor switching retained phase materially raised purity to 0.80.

K1

> A plausible explanation is that target and major impurities have similar effective partition behavior in the tested systems

Q

> Washing is expected to raise purity modestly while losing target, consistent with batches 2 and 8
