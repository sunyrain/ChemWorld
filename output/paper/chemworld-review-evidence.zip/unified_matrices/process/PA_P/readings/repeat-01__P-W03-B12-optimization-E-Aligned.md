# 重复建立上游局部关系，但被拒操作不能充当萃取机理证据

`repeat-01/P-W03-B12-optimization-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开动作和拒绝记录、K1/Q/K2及已有复测；非独立双人编码。

[完整公开记录](../sessions/repeat-01__P-W03-B12-optimization-E-Aligned.json)

## 问题与先验

正确资料将X2置于高回收/选择性位置，全场只实际尝试X2；先寻找反应组合，再围绕较好C1/S2改后处理。最初小萃取量和浓缩使样品不足，补有机液后才终检，不能作常规萃取对照。

## 预期与实验

唯一中途v2/cursor168已在第十一批后：把C1/S2三项反应指标的重复作为工作依据，下一批拟先浓缩再建高有机比例相系统。批12浓缩因has_phase_system被拒，随后加0.0002L水相建立系统并加X2、三次洗涤。实际执行并不完全等于所写计划。

## 实际证据

C1/S2批9/11/12 HPLC纯度0.628/0.619/0.624，收率约0.335/0.351/0.329，局部反应重复成立。批9终态0.6949/0.1001，批12为0.6921/0.0628。批11终态0.6236/0.3193接近反应前状态，但事件161—166的加萃取剂、混合、静置、分离、洗涤和干燥均因缺相系统被拒。不是成功加入X2后观察到不分相。

## 修订

v2/v3识别需要先建相系统，且没有合格流程；推荐较好的批9，既有复测0.6925/0.0906。K1/K2却把批11写为加入0.06L X2而无真正水相导致未净化，并将其用于相形成机制论证，超出执行记录。记录支持操作前置条件认识，不支持一次真正完成的单相萃取化学比较。

## 后续采用

Q沿资料K值推X0回收低于X2，沿未测低投料/催化剂比例推Q07—Q12更高回收0.16—0.23，且提出稀释可能抑制杂质、纯度超过已见最大值。理由承认属于外推。K2提议测同源双相物料衡算辨别分配和损失，尚未执行。

## 未解决问题及解释限制

K1的hard purity–recovery frontier不是已识别的不可突破边界：仅12批、仅X2、后处理多变量变化。K1还把C0纳入同S0共同条件排序，实际后期C0用S1，早期C0/S0温度时长体积均异。可保留C1相对C2/C3的S0比较与C1/S2重复；不可照收完整催化剂排序及被拒操作的化学解释。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 168, 'last_event_id': 'runner-operation-0168'}

> the final batch will retain an aqueous phase but increase organic:aqueous ratio by concentrating first.

事件：runner-operation-0175, runner-operation-0176, runner-operation-0186

K1

> adding extractant alone does not purify

Q

> Dilution may suppress impurity-forming pathways, motivating purity estimates somewhat above the campaign maximum, but this is extrapolation.
