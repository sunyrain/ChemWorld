# 错配萃取先验下形成有效局部反应选择，却未检验先验的材料比较

`repeat-02/P-W02-B12-optimization-E-MisIndexed`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-02__P-W02-B12-optimization-E-MisIndexed.json)

## 问题与先验

v1以资料X0最高分配与选择性起手，计划筛选并重复。实际12批全用X0且无完整重复；仅首尾两版记录，不足以逐次定位后续严重度选择的公开解释。

## 预期与实验

先固定360K1800s、S0筛四催化剂，再C3四溶剂；后续C3/S1改变温度时间和洗量，最后增加相量与洗量。C3/S1在390K1800/3600/7200s的上游比较真实，终态3600s洗0.02而其余洗0.005，终态三点不能纯作时间效应。

## 实际证据

C3/S0 selectivity0.579优于其余；C3/S1和S2上游yield0.142/0.137、最终0.838/0.0153与0.901/0.0317。390K1800→7200s固定0.005L洗，最终回收0.0276→0.0728、纯度0.852→0.406，形成明确局部时间权衡。末批同时改溶剂/水/X0/洗量，回收0.0787而纯度0.680。

## 修订

v2以C3/S2第6批为最高合格回收，明确X0相对其他X没有验证；K1/K2将长热处理高转化与严重纯度失败区别开，并不宣称具体平行反应或顺序降解已识别。第1批其实也纯度合格0.818但回收0，K1完整保留，v2示例列举未纳入不当作遗漏证据。

## 后续采用

Q仍由资料X0比X2优给Q03纯度/回收0.78/0.055对Q04的0.73/0.047。对低料量的0.23回收和等总量双洗优势依赖未检验浓度/比例与洗涤模型。K2承认未测X2与各操作，建议C3/S1固定390K时间序列区分降解和平行副反应，未执行。

## 未解决问题及解释限制

局部合格方案与未经验证材料排名并存；推荐第6比第8回收只高0.004，低于测量噪声尺度，不宣称稳健最优。没有中途笔记，K1的“改变认识”属于事后说明；也不能由持续X0证明选择性采样维持错误的完整机制。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 180, 'last_event_id': 'runner-operation-0180'}

> the categorical superiority of X0 over X1–X3 remains unresolved rather than established.

Q

> The dossier indicates that X0 has both greater product partitioning and greater product/impurity discrimination than X2

K2

> neither condition was replicated.
