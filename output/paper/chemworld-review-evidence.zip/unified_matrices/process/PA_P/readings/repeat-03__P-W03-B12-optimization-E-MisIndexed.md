# 局部催化与洗涤认识成立，未测萃取剂的预测仍由错配资料承担

`repeat-03/P-W03-B12-optimization-E-MisIndexed`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-03__P-W03-B12-optimization-E-MisIndexed.json)

## 问题与先验

错配资料使X0与X1进入探索，初始愿以反证修订。全场只有首末两版，没有中途笔记，不能从终末叙述重建每次转向的同期动机。

## 预期与实验

固定380K/3600s在S0比较C1/C2/C3，再固定C1比较S1/S2/S3；后段提高热暴露、试X1及洗涤，再低温延时。C0首批低温、稀释和强化处理均不同。

## 实际证据

C1/C2同转化约0.373/0.375但产率0.199/0.072，支持局部选择性差异。C1S2标准转化/选择性0.498/0.608，较强两批0.780/0.538、0.822/0.471。X1不洗/0.01L洗纯度0.687/0.691、回收0.091/0.061，是较匹配的无明显纯度收益且损失回收的对照。

## 修订

末笔记、K1/K2明确洗涤收益未成立、X1纯度优势未建立，无终态达0.80，推荐批6为fallback。K1正确区分相选择后近1转化与反应阶段动力学，平行副反应和降解仍并列。

## 后续采用

Q用未测X2与资料比较X0，仍预测X0较高转移与富集；Q07/08又预言洗涤使纯度0.64→0.74、回收0.25→0.11。该方向迁往未测X2与低投料条件，不能直接称与X1局部结果逻辑矛盾，但缺实验支持。K2明确X2/X3未用、低催化剂规律未识别。

## 未解决问题及解释限制

错配资料未阻止真实局部筛选与洗涤范围限定；同样也未被全面检验。首批纯度0.796/回收0不能算合格或实用成功。提出时间序列为未来候选，不是本场判别结果。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 175, 'last_event_id': 'runner-operation-0175'}

> A wash did not show a favorable tradeoff in this scope

K1

> final-assay conversion near 1 after phase separation should not be read as nearly complete reactor conversion

Q

> X0 should provide somewhat greater target transfer and enrichment than X2

K2

> Extractants X2 and X3 were not used in the completed campaign.
