# 局部热处理收益与纯度代价进入推荐，但对洗涤及新剂量的预测仍依赖未识别关系

`repeat-02/P-W04-B12-optimization-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-02__P-W04-B12-optimization-E-Aligned.json)

## 问题与先验

正确资料指引始终采用X2；v1将类别筛选与完整工艺达标结合。所有12批有终测，0.04 mol单次加料避免共享试剂提前耗尽。C1在S0、350 K/1800 s的上游纯度0.640高于其他C类别，随后扩至S1–S3；没有其他萃取剂的实验，故X2最佳仍是资料先验。

## 预期与实验

前8批后v2/cursor120见S3/C1升温延时大幅提高转化与产率，但纯度未达标，提出少量洗涤或更长反应。第8、9批同390 K/3600 s上游产率0.340/0.333，唯一处理差异为0.010 L洗涤；终纯度0.688→0.657、回收0.0676→0.0717，回收差在噪声尺度内。第10批370 K/7200 s产率0.337、转化0.686、杂质增加，终纯度0.503。

## 实际证据

C1/S2温和条件第6和11批上游产率0.0903/0.1118，末端纯度0.8114/0.8122、回收0.01997/0.01722，但X2体积0.018/0.030 L不同，不能称整个工艺严格重复。第7→8批同时升温、延时并提高X体积，末端变化不完全归于严重度；前段HPLC与处理后必须分开。

## 修订

v3与K1认识到更大反应产量并不保障末端纯度，退回温和C1/S2且省洗/干/浓缩的第6批作为推荐。明确第6与11的回收差小于测量噪声、0.80阈值附近不稳健。洗涤未显示可靠收益这一判断有实际近匹配对照；K1所说没有clean randomized pair不应被理解为完全无单因素比较，只是该一对没有随机化或多重复。

## 后续采用

Q保留延时提高回收、降低纯度的方向，并根据未测催化剂比例规律将前六组回收压低到0.004–0.019；低投料组升至0.050–0.075。Q仍预言洗涤提高纯度、分次洗更有效，属于不同浓度下额外推断，不能声称研究已证实。K2承认洗涤与剂量外推薄弱，并建议固定温度时间序列区分并行副反应与后续降解。

## 未解决问题及解释限制

真正形成的是局部类别选择和反应产量—末端质量的权衡，非已识别全局热最优点。原配方中预设控制仅首批显式调用，其他类别比较也不应忽略操作上下文。相分配、催化剂剂量与稀释关系未辨识；一次达标观察不等于稳健工艺。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> A mild wash or longer reaction is now warranted

事件：runner-operation-0134, runner-operation-0147

v3 / cursor {'event_count': 173, 'last_event_id': 'runner-operation-0173'}

> that recovery difference is smaller than the stated single-assay noise and is not strong evidence of superiority.

事件：runner-operation-0094, runner-operation-0160

Q

> Washing is expected to raise purity and lose some target
