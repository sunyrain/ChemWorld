# 实测推翻名义溶剂即有机相的假设，未测材料比较仍由资料补足

`repeat-03/PA-W01-B12-discovery-E-Aligned`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-03__PA-W01-B12-discovery-E-Aligned.json)

## 问题与先验

资料提示S2及X2/X3较强但交互未知。先做S2X3重复并保留相反相，再筛S0X0、S1X1、S2X2、S3X3，共五个独特配对；K1及末笔记称四个，计数不准确。

## 预期与实验

v2/cursor60预告相量与混合检验，并明确非单调结果削弱简单体积假设。后续把S与水添加量互换，实际相率0.193/0.178、目标有机0.440/0.402；随后真正改变X体积产生0.255→0.660。

## 实际证据

S2X3标准重复有机0.402/0.431，弱1s100rpm为0.341、强1200s1200rpm为0.507，phase_ratio相近。标准重复保留有机/水相的终检分别主要在对应通道，确立测量阶段的区别。

## 修订

v3明确推翻所有加入溶剂都计入有机相的朴素假设，将相量依据改为分离前读数；也保留混合时速混杂及平台未确定。K2进一步观察标准重复归一化比例相近，提出共同尺度扰动可能性，但仅是后验解释。

## 后续采用

Q按局部体积与混合趋势推断，S2X3的Q11/Q12为0.594/0.655；对从未测量的S0X3、S2X0借边际资料补足，D2仍选择Q06。K2明确指出Q把X3称为S0中的强者没有固定S0对照，并提出固定转速累计时间序列，未执行。

## 未解决问题及解释限制

科学正向过程是原先操作性假设经实验被修订，并改变世界表征；未知配对与可分离混合因子仍限制外推。不能因Q有点预测就判定错误，但资料与实测来源必须区别，且区间未经验校准。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 60, 'last_event_id': 'runner-operation-0060'}

> Equal outcomes within uncertainty or non-monotonic volume results would weaken these claims.

事件：runner-operation-0067, runner-operation-0077

v3 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> This disconfirms the naive assumption that all added solvent is itself organic phase.

K2

> The prediction rationale also called X3 stronger for S0, although no fixed-solvent S0 comparison established that.
