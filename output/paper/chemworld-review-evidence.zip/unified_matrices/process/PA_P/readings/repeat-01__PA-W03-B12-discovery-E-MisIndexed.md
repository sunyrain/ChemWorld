# 原拟相量干预未改变实际相比例，判断正确退回未检验

`repeat-01/PA-W03-B12-discovery-E-MisIndexed`

阅读覆盖：同一分析智能体逐版阅读完整笔记/差异、全部公开动作观测和K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-01__PA-W03-B12-discovery-E-MisIndexed.json)

## 问题与先验

资料提示S2/X0可能高转移，初始把相比例与配对分配参数分开。先完成S2萃取剂切片、X0溶剂切片及S1/X2一点。

## 预期与实验

v2/cursor80已因S2/X0仅中等转移降低资料排序地位，仍保留相量式预期，规划基准重复、对向保留相、相量和弱混合。随后S2/X0的两批把溶剂/加水0.04/0.04分别改0.02/0.06和0.06/0.02，萃取剂始终0.02L。实际并未改变萃取剂相对于非萃取液总量的比例。

## 实际证据

基准S2/X0有机0.227/0.256；两次拟相量对比0.262/0.270且测得相比例0.209/0.213，与基准相近。弱1s/100rpm有机0.206，仅小于基准范围，不能确定动力学效应。水相保留批9观测水相0.725→终检0.753、有机归零，支持实际保留语义。

## 修订

v3未把相量对比无差异写成反证分配式，而明确实际相比例没有形成预期干预，故相量效应未被检验。K1仍提出可能相体积变换等解释，K2进一步从完整配方指出总非萃取液恒定，实验设计/操作语义即可解释该问题，不需要先发明未知化学机制。

## 后续采用

Q把未验证相量式作为工作预测，S0/X3未测却以跨切片和资料推Q06高于Q05并选择Q06；K2承认此决策比证据强、uncertain更稳妥。Q对混合强度差异给小调整，因为查询远强于唯一弱混合点，但没有实验平台证据。

## 未解决问题及解释限制

本场重要认识进展包括识别自己的干预未实现、拒绝把无效对比当物理规律反例。仍保留的相量及平台预测是建模外推；不能因为模型明确承认未检验就说它已误认为定律，也不能把K2的新建议当已完成检验。

## 已核验引文与事件锚点

v3 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> nominal additions did not yield the assumed actual phase-volume contrast.

事件：runner-operation-0097, runner-operation-0107

K2

> both kept 0.02 L extractant against 0.08 L combined nonextractant liquid, so they did not test that volume law.

Q

> Q06 is the more likely of Q05 and Q06 to place target in the organic phase, although their intervals overlap.
