# 交叉配对使单因素优势失效，非线性与混合成为工作解释

`repeat-01/PA-W03-B12-discovery-E-Opaque`

阅读覆盖：同一分析智能体阅读全部笔记/差异、公开操作/测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-01__PA-W03-B12-discovery-E-Opaque.json)

## 问题与先验

无材料资料，初始提出配对、相量与混合假设，并强调库存份额不能当浓度。前七批分别固定S0扫萃取剂、固定X0扫溶剂。

## 预期与实验

v2/cursor70已提出S3/X3交叉点检验两种有利替换是否可加，并承诺相量和弱/强混合对比。随后最后五批实际实施该配对基准、低/高相量、弱/强混合；初始拟有重复，最终无完全相同批次，v3/K1正确承认这一点。

## 实际证据

有机份额S0/X0为0.239、S0/X3为0.496、S3/X0为0.475，却S3/X3为0.386；这套局部2×2支持相同替换效果随搭档变化。S3/X3相比例0.094→0.509时有机0.175→0.576；弱/普通/强混合0.326/0.386/0.473。由实测相比例和库存估算分配比随相量约2.10/1.70/1.28变化，不能据此单独确立容量或活度机制。

## 修订

v3将独立材料分数改成配对解释，将相比例和混合史都纳入局部预测；拒绝单一恒定分配系数。对终检只作保留相语义检查，水相保留后的纯度变化因条件不同不当作独立杂质分配证据。

## 后续采用

Q对已测S0/X0与S0/X3采用直接差异，D2选Q06；未测S2/X3的Q08/Q11/Q12区间明显较宽，仍需借可迁移混合强度描述外推。K2提出保持时长×转速相同而改变二者比例的实验区分接触剂量与时间/剪切解释，但未执行。

## 未解决问题及解释限制

本场在受测配对内确有从观察到竞争解释和检验的过程，并非只在结尾命名交互。不能将一个配对的混合规律、含试剂的归一化行为或恒定系数失败机制扩至所有查询；时间和转速仍混杂，独立过程方差未估计。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 70, 'last_event_id': 'runner-operation-0070'}

> A crossed S3–X3 condition will test whether favorable single-factor changes combine approximately.

事件：runner-operation-0077

v3 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> The defensible claim is protocol dependence, not a unique equilibrium rate law.

事件：runner-operation-0077, runner-operation-0107, runner-operation-0117

Q

> they are widest for unmeasured S2–X3 interactions and speed/duration extrapolations.
