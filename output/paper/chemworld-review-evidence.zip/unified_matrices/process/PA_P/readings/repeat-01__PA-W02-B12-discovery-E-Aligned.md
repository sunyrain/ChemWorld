# 由初筛确定研究对象，再撤回早期混合平台

`repeat-01/PA-W02-B12-discovery-E-Aligned`

阅读覆盖：同一分析智能体阅读全部笔记及完整修订差异、全部公开操作/测量、K1/Q/K2；不是独立双人编码。

[完整公开记录](../sessions/repeat-01__PA-W02-B12-discovery-E-Aligned.json)

## 问题与先验

资料只给跨搭档平均倾向，初始记录因此把S2及X2/X3当作候选而非已知最佳配对。五个初筛组合之间可比较总差异，但不是交叉全因子设计。

## 预期与实验

v2/cursor50明确将初筛有较大有机份额的S2/X3选为后续相量和混合研究对象：预测增大有机相单调增加转移，1800s/1200rpm相对300s/600rpm只应小幅改变。随后确实保持配对实施相量、弱/强混合、重复和水相保留。

## 实际证据

S2/X3低相比例0.113时有机0.305，基准三次0.483/0.502/0.535，高相比例约0.39时0.701/0.724；形成范围明确的相量关系。弱5s/100rpm为0.404、强1800s/1200rpm为0.608，超出普通重复范围。事件107至110及117至120验证保留水相后相比例近零，水相库存分别约0.458→0.486、0.301→0.308。

## 修订

v3明确否定早期平台，保留混合增强作用，并承认时间和转速仍混杂。局部分配参数约3.6—3.9被限定为有用近似，不能升级为所有配对共享常数。相比预先规定的检验方向，修订有时间顺序和实际结果支持。

## 后续采用

Q采用随混合增强的转移、相量关系及精确互补份额。S2/X3相关预测区间较窄；S0/X3与S2/X0未直接测量，借资料边际倾向及间接比较外推并给较宽区间。D2选Q06。K2指出Q理由中所谓观察到的X3优于X0并无同溶剂直接比较，提出追加S0/X3检验以辨别交互作用，但未执行。

## 未解决问题及解释限制

本场最明确的正向过程是初筛结果引导后续设计、平台预期被新证据撤回、局部相量关系得到重复支持。未测配对的可分离外推仍有未识别部分；不能将其泛化为全部推断无效，也不能用K2事后建议冒充追加实验。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 50, 'last_event_id': 'runner-operation-0050'}

> whereas 1800 s/1200 rpm should be similar to or only modestly above the baseline.

事件：runner-operation-0087, runner-operation-0097

v3 / cursor {'event_count': 120, 'last_event_id': 'runner-operation-0120'}

> H3 [rejected as an early plateau; mixing effect supported over tested range]

事件：runner-operation-0027, runner-operation-0077, runner-operation-0087, runner-operation-0097, runner-operation-0107

K2

> that ordering came partly from the supplied marginal dossier and indirect screening.
