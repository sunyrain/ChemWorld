# 系统比较直接终检与四种萃取流程形成失败边界，后续预测依赖未测催化剂缩放

`repeat-02/P-W03-B12-optimization-E-Opaque`

阅读覆盖：同一分析智能体完整阅读笔记/差异、全部公开操作测量及K1/Q/K2；非独立双人编码。

[完整公开记录](../sessions/repeat-02__P-W03-B12-optimization-E-Opaque.json)

## 问题与先验

v1预期普通反应加萃取洗涤能跨0.80，低回收将促改相操作。实际首批有机流程回收0后，第二至七批直接终检，随后完整四萃取剂筛选及水相替代。只有首尾笔记，不能直接定位每次改向的同期解释。

## 预期与实验

C1/C2/C3于S0、350K3600s直接终检比较；首批C0含下游且溶剂0.05L而其他0.04L，末笔记将其并列是粗化，K1部分纠正域差异。C1于400K7200s比较S1–S3，再用S2固定上游测试四X。后五批HPLC改到完整后处理之后，不能误作各批反应前锚点。

## 实际证据

直接C1/C2/C3纯度/回收0.522/0.135、0.196/0.057、0.419/0.090。高严重度S1/S2/S3为0.503/0.347、0.567/0.422、0.320/0.224。四X有机流程最终纯度0.484–0.532、回收0.096–0.128；改保留水相0.565/0.230，但同时取消wash/dry。

## 修订

终点撤回本次流程能达0.80的预期，推荐直接S2第6批并明确不合格。K1利用直接终检yield约conversion×selectivity建立有范围的关系，区分后处理高conversion与全反应完成，不把最高回收当合格解决方案。

## 后续采用

Q以实际S2/X2源终态0.532/0.128作锚，低催化剂量假定速率近线性，使Q01–06回收0.004–0.018；低料量恢复催化剂/试剂比，给0.111–0.140。该缩放未实验，K2提出同第6批只降催化剂20倍并以低于0.10或接近0.42区分，未执行。

## 未解决问题及解释限制

四种X完整流程无选择性收益构成可用负向边界，但不能独归萃取本身；水相优于有机也混杂wash/dry。源研究中的测量时点改变决定可解释内容，无同批双相质量平衡、无完整重复。非合格流程仍产生了真实比较认识。

## 已核验引文与事件锚点

v1 / cursor {'event_count': 0, 'last_event_id': None}

> A result with high conversion but low final recovery will motivate changing phase handling

K1

> The post-workup HPLC and final-assay results agreed closely enough

K2

> directly tests the largest unsupported extrapolation behind predictions Q01–Q06.
