# 局部反应关系和纯度门槛的零回收解并存，共享库存使第十二批无法检验

`repeat-01/P-W05-B12-optimization-E-Opaque`

阅读覆盖：同一分析智能体完整阅读两版笔记、全部公开操作测量及K1/Q/K2，读取已有推荐复测；非独立双人编码。

[完整公开记录](../sessions/repeat-01__P-W05-B12-optimization-E-Opaque.json)

## 问题与先验

无资料，计划材料及温时筛选后改变萃取和洗涤；v1预告若目标偏水则反转保留相。只有起点与末尾两版笔记，不能把K1按批重述的解释变化均认作中途封存。

## 预期与实验

先有机后水相，再做少后处理的高温反应，最后对C1/S2优良反应重复并用X2提纯。batch5另加0.04mol component0消耗共同库存，11批正常投料加该额外投料共0.48mol，导致第12批投料被拒；其零信号不是低效反应实验。

## 实际证据

C1/S0与C1/S2同420K/7200s直接终态回收0.314/0.472、纯度0.514/0.593；C3/S2同条件回收0.317/纯度0.484。batch7/11相同上游HPLC回收0.471/0.462，batch11 X2有机后纯度0.613/回收0.217，显示下游损失且纯度改善有限。batch1纯度0.8227但报告回收0，是唯一达观察门槛的终态。

## 修订

v2及K1明确X2不能自动解决纯化，区分最终样品转化和反应器转化。K1把反应近似yield≈conversion×selectivity与分配/损失分层，但强催化剂—溶剂交互仍缺完整交叉证据。11/12终检完成；第12批被弃且不用于化学推断。

## 后续采用

依规则推荐batch1而非最大回收不合格batch7，明确这是形式门槛解而非实用成功。已有复测纯度0.8114/回收0.00144，仍极低。Q迁移C1/S2 X2局部解释，并从不同上游X0批推断其更提纯、更损失；K2指出该比较混杂。Q07—12以恢复催化剂/试剂比例预测较高回收，K2提出降低两者20倍的匹配试验来区分比例与浓度机制，未执行。

## 未解决问题及解释限制

第12批缺失是研究操作造成的资源分配后果，不是provider或平台失效。batch6—10浓缩因has_phase_system拒绝，所称直接终态应理解为该操作未提交后的结果。回收0是带噪声仪器边界，不可断言所有目标分子已消失；真实局部上游进展与目标未获实用满足并存。

## 已核验引文与事件锚点

v2 / cursor {'event_count': 156, 'last_event_id': 'runner-operation-0156'}

> This is a resource-allocation failure, not evidence about chemistry.

事件：runner-operation-0138, runner-operation-0156

K1

> Batch 12 did not constitute a valid chemical experiment.

K2

> It is not a reliable practical recommendation because its measured recovery was zero.
